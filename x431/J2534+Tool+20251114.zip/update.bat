@echo off
for %%f in (*.exe) do (
    echo Starting %%f
    start "" "%%f"
)

exit