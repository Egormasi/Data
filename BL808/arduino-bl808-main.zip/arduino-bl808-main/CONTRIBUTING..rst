Contributions Guide
===================

We welcome contributions to the Arduino BL808 project!

How to Contribute
-----------------

Contributions to Arduino BL808 - fixing bugs, adding features, adding documentation - are welcome. We accept contributions via `Github Pull Requests <https://help.github.com/en/github/collaborating-with-issues-and-pull-requests/about-pull-requests>`_.

Before Contributing
-------------------

Before sending us a Pull Request, please consider this list of points:

* Is the contribution entirely your own work, or already licensed under an LGPL 2.1 compatible Open Source License? If not then we unfortunately cannot accept it.

* Is the code adequately commented for people to understand how it is structured?

* Is there documentation or examples that go with code contributions? 

* Are comments and documentation written in clear English, with no spelling or grammar errors?

* Example contributions are also welcome.

* If the contribution contains multiple commits, are they grouped together into logical changes (one major change per pull request)? Are any commits with names like "fixed typo" `squashed into previous commits <https://eli.thegreenplace.net/2014/02/19/squashing-github-pull-requests-into-a-single-commit/>`_?

* If you're unsure about any of these points, please open the Pull Request anyhow and then ask us for feedback.

Pull Request Process
--------------------

After you open the Pull Request, there will probably be some discussion in the comments field of the request itself.

Once the Pull Request is ready to merge, it will first be merged into our internal git system for in-house automated testing.

If this process passes, it will be merged onto the public github repository.
